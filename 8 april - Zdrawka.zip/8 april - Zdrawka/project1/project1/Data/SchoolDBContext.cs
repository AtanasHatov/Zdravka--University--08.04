﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace project1.Data
{
    public class SchoolDBContext : DbContext
    {
        public SchoolDBContext() : base()
        {
        }

        public DbSet<University> Universitys { get; set; }
        public DbSet<Faculty> Facultys { get; set; }
        public DbSet<Major> Majors { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
        }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer("Data Source=STUDENT7;Initial Catalog=LibraryDBC;Integrated Security=True;Encrypt=False;Trust Server Certificate=True");
        }
    }
}
