﻿using project1.Controllers;
using project1.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace project1.Presentation
{
    public class Display
    {
        UniversityController UniversityController=new UniversityController();
        FacultyController FacultyController=new FacultyController();
        MajorController MajorController=new MajorController();
        public async Task ShowMenu()
        {
            while(true)
            {
                Console.WriteLine("Menu");
                Console.WriteLine("1. Add university");
                Console.WriteLine("2. Add faculty");
                Console.WriteLine("3. Add major");
                Console.WriteLine("4. Show all universities");
                Console.WriteLine("5. Show faculties by university ID");
                Console.WriteLine("6. Show majors by faculty ID");
                Console.WriteLine("7. Show university ID by name");
                Console.WriteLine("8. Show faculty ID and name by name");
                Console.WriteLine("9. Show major ID and name by name");
                Console.WriteLine("10. Exit");

                int n=int.Parse(Console.ReadLine());

                if (n == 10)
                {
                    break;
                }

                switch (n)
                {
                    case 1:
                        InputUniversity();
                        break;
                    case 2:
                        InputFaculty();
                        break;
                    case 3:
                        InputMajor();
                        break;
                    case 4:
                        GetAllUniversities();
                        break;
                    case 5:
                        GetFacultiesByUniversityId();
                        break;
                    case 6:
                        GetMajorsByFacultyId();
                        break;
                    case 7:
                        GetUniversityIdByName();
                        break;
                    case 8:
                        GetFacultyIdAndNameByName();
                        break;
                    case 9:
                        GetMajorIdAndNameByName();
                        break;
                    case 10:
                        Console.WriteLine();
                        break;

                }

            }
        }

        public async Task InputUniversity()
        {
            Console.WriteLine("име на университет");
            string name=Console.ReadLine();
            UniversityController.AddUniversity(name);
        }

        public async Task InputFaculty()
        {
            Console.WriteLine("името на факултета");
            string name=Console.ReadLine();
            Console.WriteLine("ID на университета");
            int iduni=int.Parse(Console.ReadLine());
            FacultyController.AddFaculty(name, iduni);
        }

        public async Task InputMajor()
        {
            Console.WriteLine("името на специалността");
            string name=Console.ReadLine();
            Console.WriteLine("ID на факултета");
            int idmah=int.Parse(Console.ReadLine());
            MajorController.AddMajor(name, idmah);
        }

        public async Task GetAllUniversities()
        {
            List<University> inu = await UniversityController.GetAllUniversities();
            if (inu.Count <= 0)
            {
                Console.WriteLine("Prazno");
            }
            else
            {
                foreach (var item in inu)
                {
                    Console.WriteLine($"{item.Name}");
                }
            }
        }

        public async Task GetFacultiesByUniversityId()
        {
            Console.WriteLine("ID");
            int id = int.Parse(Console.ReadLine());
            List<Faculty> fac=await FacultyController.GetFacultiesByUniversityId(id);
            if (fac.Count <= 0)
            {
                Console.WriteLine("Prazno");
            }
            else
            {
                foreach (var item in fac)
                {
                    Console.WriteLine($"{item.Name}");
                }
            }
        }

        public async Task GetMajorsByFacultyId()
        {
            Console.WriteLine("ID");
            int id = int.Parse(Console.ReadLine());
            List<Major> fac = await MajorController.GetMajorsByFacultyId(id);
            if (fac.Count <= 0)
            {
                Console.WriteLine("Prazno");
            }
            else
            {
                foreach (var item in fac)
                {
                    Console.WriteLine($"{item.Name}");
                }
            }
        }

        public async Task GetUniversityIdByName()
        {
            Console.WriteLine("name");
            string name = Console.ReadLine();
            University university=await UniversityController.GetUniversityByName(name);
            if (university ==null)
            {
                Console.WriteLine("Prazno");
            }
            else
            {
                Console.WriteLine($"{university.Id}");
            }
        }

        public async Task GetFacultyIdAndNameByName()
        {
            Console.WriteLine("name");
            string name = Console.ReadLine();
            Console.WriteLine("ID");
            int id=int.Parse(Console.ReadLine());
            Faculty fac = await FacultyController.GetFacultyByNameAndUniversityId(name,id);
            if (fac == null)
            {
                Console.WriteLine("Prazno");
            }
            else
            {
                Console.WriteLine($"{fac.Id} - {fac.Name}");
            }
        }

        public async Task GetMajorIdAndNameByName()
        {
            Console.WriteLine("name");
            string name = Console.ReadLine();
            List<Major> major= await MajorController.GetMajorsByName(name);
            if (major.Count <= 0)
            {
                Console.WriteLine("Prazno");
            }
            else
            {
                foreach (var item in major)
                {
                    Console.WriteLine($"{item.Name} - {item.Id}");
                }
            }
        }
    }


}
