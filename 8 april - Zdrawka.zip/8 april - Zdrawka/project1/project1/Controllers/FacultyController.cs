﻿using Microsoft.EntityFrameworkCore;
using project1.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace project1.Controllers
{
    public class FacultyController
    {
        SchoolDBContext SchoolDBContext=new SchoolDBContext();

        public async Task AddFaculty(string name, int universityId)
        {
            Faculty faculty = new Faculty() 
            {
                Name = name,
                UniversityId = universityId
            };
            SchoolDBContext.Facultys.Add(faculty);
        }

        public async Task<List<Faculty>> GetFacultiesByUniversityId(int universityId)
        {
            var fac=await SchoolDBContext.Facultys.Where(f=>f.UniversityId==universityId).ToListAsync();
            return fac;
        }

        public async Task<List<Faculty>> GetFacultiesByName(string name)
        {
            var fac=await SchoolDBContext.Facultys.Where(f=>f.Name==name).ToListAsync();
            return fac;
        }

        public async Task<Faculty> GetFacultyByNameAndUniversityId(string name, int universityId)
        {
            var fac=await SchoolDBContext.Facultys.FirstOrDefaultAsync(f=>f.Name==name && f.UniversityId == universityId);
            return fac;
        }
    }
}
