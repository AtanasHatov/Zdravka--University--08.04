﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Storage.Json;
using project1.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace project1.Controllers
{
    public class UniversityController
    {
        SchoolDBContext SchoolDBContext = new SchoolDBContext();

        public async Task AddUniversity(string name)
        {
            University university = new University()
            {
                Name =name,
            };
            SchoolDBContext.Universitys.Add(university);
        }

        public async Task<List<University>> GetAllUniversities()
        {
            var uni=await SchoolDBContext.Universitys.ToListAsync();
            return uni;
        }

        public async Task<University> GetUniversityByName(string name)
        {
            var uni=await SchoolDBContext.Universitys.FirstOrDefaultAsync(u=> u.Name==name);
            return uni;
        }

        public async Task<int> GetUniversityIdByName(string name)
        {
            var uni =await SchoolDBContext.Universitys.FirstOrDefaultAsync(u=>u.Name==name);
            return uni.Id;
        }
    }
}
