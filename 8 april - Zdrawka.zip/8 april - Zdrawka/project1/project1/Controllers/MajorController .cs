﻿using Microsoft.EntityFrameworkCore;
using project1.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace project1.Controllers
{
    public class MajorController
    {
        SchoolDBContext SchoolDBContext=new SchoolDBContext();

        public async Task AddMajor(string name, int facultyId)
        {
            Major major = new Major()
            {
                Name = name,
                FacultyId= facultyId
            };

            SchoolDBContext.Majors.Add(major);
        }

        public async Task<List<Major>> GetMajorsByFacultyId(int facultyId)
        {
            var maj=await SchoolDBContext.Majors.Where(m=>m.FacultyId==facultyId).ToListAsync();    
            return maj;
        }

        public async Task<List<Major>> GetMajorsByName(string name)
        {
            var maj=await SchoolDBContext.Majors.Where(m=>m.Name==name).ToListAsync();
            return maj;
        }

        public async Task<Major> GetMajorByNameAndFacultyId(string name, int facultyId)
        {
            var maj=await SchoolDBContext.Majors.FirstOrDefaultAsync(m=>m.Name==name && m.FacultyId==facultyId);
            return maj;
        }
    }
}
